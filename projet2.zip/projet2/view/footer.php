</div> <!-- Fin du container -->

<footer class="bg-dark text-light text-center py-3 mt-4">
    <p>&copy; 2025 ESSECT Clubs | Tous droits réservés</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>